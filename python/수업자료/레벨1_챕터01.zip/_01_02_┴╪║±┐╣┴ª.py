"""
[1]  find 함수는 문자열데이터에 특정값이 있는지 확인해준다.
    특정값을 찾으면 인덱스를 반환해준다.
    못찾으면 -1을 반환해준다.
"""

a = "abcdefg"
test1 = a.find("b") # 1
print(test1)

test2 = a.find("z") # -1
print(test2)




