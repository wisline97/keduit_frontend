# https://school.programmers.co.kr/learn/courses/30/lessons/82612
def solution(price, money, count):
        return 0


price = 3
money = 20
count = 4
result = solution(price , money , count)
print(result)