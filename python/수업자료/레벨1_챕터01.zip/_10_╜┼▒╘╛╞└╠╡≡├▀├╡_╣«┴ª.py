# https://school.programmers.co.kr/learn/courses/30/lessons/72410
def solution(new_id):
    answer = new_id
    return answer

new_id = "...!@BaT#*..y.abcdefghijklm"
#new_id = "z-+.^."
#new_id = "=.="
#new_id = "123_.def"
#new_id = "abcdefghijklmn.p"
result = solution(new_id)
print(result)