#https://school.programmers.co.kr/learn/courses/30/lessons/87389
def solution(n):
    answer = 0
   
    return answer
    
n = 10
result = solution(n)
print(result)