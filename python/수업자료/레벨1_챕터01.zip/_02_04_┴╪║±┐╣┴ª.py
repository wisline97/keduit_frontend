"""
[1] in 키워드 
    리스트 안의 값을 찾을때 in 을 사용할수있다.
"""
a = [1,54,3,5,8]
if 1 in a:
    print(1)
else:
    print(0)





