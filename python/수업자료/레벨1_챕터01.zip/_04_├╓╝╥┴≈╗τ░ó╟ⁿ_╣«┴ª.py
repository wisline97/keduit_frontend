
# https://school.programmers.co.kr/learn/courses/30/lessons/86491
def solution(size):
    answer = 0

    return answer

size = [[60, 50], [30, 70], [60, 30], [80, 40]]
#size = [[3, 5], [6, 2]]
result = solution(size)
print(result)

