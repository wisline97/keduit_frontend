# https://school.programmers.co.kr/learn/courses/30/lessons/77884
def solution(left, right):
    
    return 0

left = 13
right = 17
result = solution(left , right)
print(result)