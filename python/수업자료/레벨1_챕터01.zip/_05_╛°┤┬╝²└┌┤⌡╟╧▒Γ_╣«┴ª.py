
# https://school.programmers.co.kr/learn/courses/30/lessons/86051
def solution(numbers):
    total = 0
    return 0
numbers = [1,2,3,4,6,7,8,0]

result = solution(numbers)
print(result)