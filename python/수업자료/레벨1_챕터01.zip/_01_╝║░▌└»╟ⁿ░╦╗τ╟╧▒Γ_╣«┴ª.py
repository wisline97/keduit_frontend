# https://school.programmers.co.kr/learn/courses/30/lessons/118666


def solution(survey, choices):
    answer = ''
    
    return answer

survey = ["AN", "CF", "MJ", "RT", "NA"]
choices = [5,3,2,7,5]
r = solution(survey , choices)
print(r)