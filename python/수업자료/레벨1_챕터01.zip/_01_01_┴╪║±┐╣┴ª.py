"""
[1] 포문을 이용해서 0으로 가득찬 리스트 만들기
"""
test = [0 for i in range(5)]
print(test)






