# https://school.programmers.co.kr/learn/courses/30/lessons/81301

def solution(s):
    sample = ["zero" , "one" , "two" , "three" , "four" , "five" , "six" , "seven" , "eight" , "nine"]

    return 0

s = "one4seveneight"

result = solution(s)

print(result)

