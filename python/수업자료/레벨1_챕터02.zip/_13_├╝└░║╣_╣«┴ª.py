# https://school.programmers.co.kr/learn/courses/30/lessons/42862

def solution(n, lost, reserve):
    answer = 0
    
    return answer


n = 5
lost = [1,2]
reserve = [2,3]
result = solution(n, lost, reserve)
print(result)