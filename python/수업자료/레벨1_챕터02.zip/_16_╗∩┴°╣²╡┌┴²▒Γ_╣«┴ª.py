# https://school.programmers.co.kr/learn/courses/30/lessons/68935

def solution(n):
    answer = 0
    
    return answer
n = 45
result = solution(n)
print(result)