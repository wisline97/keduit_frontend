# https://school.programmers.co.kr/learn/courses/30/lessons/42889

def solution(N, stages):
    answer = []
   
    return answer

N = 5
stages = [2, 1, 2, 6, 2, 4, 3, 3]
result = solution(N , stages)
print(result)