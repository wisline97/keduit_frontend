# https://school.programmers.co.kr/learn/courses/30/lessons/68644

def solution(numbers):
    answer = []
   
    return answer

numbers = [2,1,3,4,1]
result = solution(numbers)
print(result)

